import React from 'react';
import { View, Text, Button } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold' }}>Available Restaurants</Text>
      <View style={{ marginVertical: 10 }}>
        <Text>La Piazza - Italian</Text>
        <Button title="Book Table" onPress={() => alert('Navigate to Booking Screen')} />
      </View>
      <View style={{ marginVertical: 10 }}>
        <Text>Sushi Zen - Japanese</Text>
        <Button title="Book Table" onPress={() => alert('Navigate to Booking Screen')} />
      </View>
    </View>
  );
}
